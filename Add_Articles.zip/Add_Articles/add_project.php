<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "articlesDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $content = $_POST['content'];

    $stmt = $conn->prepare("INSERT INTO articles (title, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $content);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Article added successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Article</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h2, h3 {
            text-align: center;
            color: #343a40;
        }
    </style>
</head>
<body class="container mt-5">
    <h2>Add New Article</h2>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Content</label>
            <textarea name="content" class="form-control" rows="5" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary w-100">Add Article</button>
    </form>
    
    <hr>
    <h3>Existing Articles</h3>
    <ul class="list-group">
        <?php
        $result = $conn->query("SELECT * FROM articles ORDER BY created_at DESC");
        while ($row = $result->fetch_assoc()) {
            echo "<li class='list-group-item'><strong>" . htmlspecialchars($row['title']) . "</strong><br>" . nl2br(htmlspecialchars($row['content'])) . "</li>";
        }
        ?>
    </ul>
</body>
</html>

<?php
$conn->close();
?>
